@extends('static')

@section('title','All Categories')

@section('content')








<div class="container-fluid">
    <div class="row">
      <div class="col-sm">
       <h1>All Categories </h1>
      </div>
      <div class="col-sm">
        
      </div>
      <div class="col-sm">
        <a href="{{ route('categories.create') }} " class="btn btn-dark">Add New Post</a>
      </div> 
    </div>
  </div>



<div class="container-fluid">
<table class="table">
    <thead class="thead-dark">
      <tr>
        <th scope="col">ID</th>
        <th scope="col">Category Name</th>
      
        <th scope="col">PUBLISHED DATE</th>
        <th scope="col">ACTION</th>
      </tr>
    </thead>
    <tbody>


        
@foreach ($categories as $categories)
{!!   Form::model($categories, ['route' => ['categories.destroy', $categories->id], 'method' => 'DELETE'])  !!}   
    
<tr>
    <th scope="row">{{ $categories->id}}</th>
    <td>{{ $categories->name}}</td>
    {{-- <td>{{ substr(strip_tags($post->body),0,100)}}</td>    --}}
    <td>{{ date('M j, Y h:ia', strtotime($categories->created_at))  }}</td>
    <td>
    {{-- <a href="{{route('categories.show',$categories->id )}}" class="btn btn-dark" >
        <i class="fas fa-eye"></i></a> --}}
        <a href="{{route('categories.edit',$categories->id )}}" class="btn btn-dark"><i class="fas fa-edit"></i></a>

        {{-- {{ Form::button('<i class="fa fa-trash"></i>', ['class'=> '']) }} --}}

        {{ FORM::button('<i class="fa fa-trash"></i>',['class'=>'btn btn-danger','type'=>'submit','id'=>'id-button']) }}

         {{-- <a href="{{route('posts.destroy',$post->id )}}"></a> --}}</td>
  </tr>
 

@endforeach

    </tbody>
  </table>

</div>





@endsection