@extends('static')

@section('title','Create Categories')

@section('content')





{!! Form::open(['route' => 'categories.store', 'files' => true ]) !!}

{!! Form::label('name','Category Name:'); !!}
{!! Form::text('name',null, array('class' => 'form-control' )) !!}






{!! Form::submit('Create Post', array('class' => 'btn btn-success btn-lg btn-block')) !!}

{!! Form::close() !!}









@endsection