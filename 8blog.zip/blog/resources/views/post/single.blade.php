@extends('static')


@section('title',$post->title)

@section('head_tags')

<style>

    

</style>

@endsection

@section('content')
    





<div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <img src="{{asset('images/'. $post->image)}}" alt="">
    
        <h1>{{ $post->title}}</h1>
    <h6>Category{{$post->category->name}}</h6>
        <p>{!! $post->body  !!}</p>

    </div>

    
    
  </div>

  <div class="col-2"></div>




@endsection