@extends('static')


@section('head_tags')

<script src="https://cdn.tiny.cloud/1/qixyqom2q3ozdkbv5uab0u4vv8hh2obcxyuyqzeuxh761y6t/tinymce/5/tinymce.min.js"></script>
<script>
tinymce.init({
    selector: 'textarea'
});
</script>
@endsection


@section('title','ali')

@section('content')

<style>
row{
    width: 0% ;
}
</style>

<div class="row">
    <div class="col-1"></div>
    <div class="col-7">
        



       





{!!   Form::model($post, ['route' => ['posts.update', $post->id], 'method' => 'PUT','files' => true])  !!}

{!! Form::label('title','Title:'); !!}
{{ Form::text('title', null, [ 'class'=> 'form-control'])}}


{!! Form::label('featured_image','Upload Featured Image'); !!}
{!! Form::file('featured_image'); !!}



{!! Form::label('body','Post Body:'); !!}
{{ Form::textarea('body', null, [ 'class'=> 'form-control'])}}


        {{-- <h2>{{ $post->title}}</h2>

        <p>{{ $post->body}}</p>
        <p>{{ date('M j, Y h:ia', strtotime($post->created_at))  }}</p> --}}


    {!! Html::linkRoute('posts.show', 'Cancel', array($post->id),array('class' =>'btn btn-danger btn-block')) !!}
    
    {{ Form::submit('Save Changes', ['class'=> 'btn btn-dark btn-block']) }}
  

    </div>
        </div>

    <div class="col-4">col-4</div>
  </div>







@endsection