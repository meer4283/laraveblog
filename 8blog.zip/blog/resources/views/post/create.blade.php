@extends('static')

@section('title','Create Post')

@section('head_tags')

<script src="https://cdn.tiny.cloud/1/qixyqom2q3ozdkbv5uab0u4vv8hh2obcxyuyqzeuxh761y6t/tinymce/5/tinymce.min.js"></script>
<script>
tinymce.init({
    selector: 'textarea'
});
</script>
@endsection




@section('content')

<div class="row">
<div class="col-md-8 col-md-offset-2">

{!! Form::open(['route' => 'posts.store', 'files' => true ]) !!}

{!! Form::label('title','Title:'); !!}
{!! Form::text('title',null, array('class' => 'form-control' )) !!}




{!! Form::label('featured_image','Upload Featured Image'); !!}
{!! Form::file('featured_image'); !!}


{!! Form::label('body','Post Body:'); !!}
{!! Form::textarea('body',null, array('class' => 'form-control' )) !!}

{!! Form::label('category_id','Put Category ID:'); !!}
{!! Form::text('category_id',null, array('class' => 'form-control' )) !!}


<br>

{!! Form::submit('Create Post', array('class' => 'btn btn-success btn-lg btn-block')) !!}

{!! Form::close() !!}

</div>

<div class="col-md-4">

</div>   

</div>
@endsection