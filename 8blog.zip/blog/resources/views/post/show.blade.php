@extends('static')


@section('title',$post->title)

@section('content')

<style>
row{
    width: 0% ;
}
</style>

<div class="row">
    <div class="col-1"></div>
    <div class="col-7">
    {!!   Form::model($post, ['route' => ['posts.destroy', $post->id], 'method' => 'DELETE'])  !!}   
        <h2>{{ $post->title}}</h2>

        
    <img src="{{ asset('images/'. $post->image)}}" alt="">
        <p>{!! $post->body !!}</p>
        <p>{{ date('M j, Y h:ia', strtotime($post->created_at))  }}</p>


    {!! Html::linkRoute('posts.edit', 'Edit', array($post->id),array('class' =>'btn btn-primary btn-block')) !!}
    {{-- {!! Html::linkRoute('posts.destroy', 'Delete', array($post->id),array('class' =>'btn btn-danger btn-block')) !!}
    --}}
    {{ Form::submit('Delete', ['class'=> 'btn btn-danger btn-block']) }}
    </div>
        </div>

    <div class="col-4">col-4</div>
  </div>







@endsection