@extends('static')

@section('title','All post')

@section('content')








<div class="container-fluid">
    <div class="row">
      <div class="col-sm">
       <h1>All Posts </h1>
      </div>
      <div class="col-sm">
        
      </div>
      <div class="col-sm">
        <a href="{{ route('posts.create') }} " class="btn btn-dark">Add New Post</a>
      </div> 
    </div>
  </div>



<div class="container-fluid">
<table class="table">
    <thead class="thead-dark">
      <tr>
        <th scope="col">ID</th>
        <th scope="col">TITLE</th>
        <th scope="col">POST</th>
        <th scope="col">PUBLISHED DATE</th>
        <th scope="col">ACTION</th>
      </tr>
    </thead>
    <tbody>


        
@foreach ($post as $post)
{!!   Form::model($post, ['route' => ['posts.destroy', $post->id], 'method' => 'DELETE'])  !!}   
    
<tr>
    <th scope="row">{{ $post->id}}</th>
    <td>{{ $post->title}}</td>
    <td>{{ substr(strip_tags($post->body),0,100)}}</td>   
    <td>{{ date('M j, Y h:ia', strtotime($post->created_at))  }}</td>

    <td><a href="{{route('posts.show',$post->id )}}" class="btn btn-dark" >
        <i class="fas fa-eye"></i></a>
        <a href="{{route('posts.edit',$post->id )}}" class="btn btn-dark"><i class="fas fa-edit"></i></a>

        {{-- {{ Form::button('<i class="fa fa-trash"></i>', ['class'=> '']) }} --}}

        {{ FORM::button('<i class="fa fa-trash"></i>',['class'=>'btn btn-danger','type'=>'submit','id'=>'id-button']) }}

         {{-- <a href="{{route('posts.destroy',$post->id )}}"></a></td> --}}
  </tr>
 

@endforeach

    </tbody>
  </table>

</div>





@endsection