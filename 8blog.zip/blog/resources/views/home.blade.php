@extends('static')


@section('title','Dashboard')



@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    You are logged in!

                    <table class="table">
                     
                        <tbody>
                          <tr>
                            <th scope="row"><a href="/posts" class="btn btn-dark btn-block"> Delete Post</a></th>
                            <th scope="row"><a href="/posts/create" class="btn btn-dark btn-block"> Create Post</a></th>
                            <td><a href="/posts" class="btn btn-dark btn-block"> See All Post</a></td>
                                
                          </tr>
                          <tr>
                            <th scope="row"><a href="/categories/create" class="btn btn-dark btn-block"> Create categories</a></th>
                            <td><a href="/categories" class="btn btn-dark btn-block"> See All categories</a></td>
                         
                            
                          </tr>
                         
                        </tbody>
                      </table>


                    <a class="dropdown-item" href="{{ route('logout') }}"
                    onclick="event.preventDefault();
                                  document.getElementById('logout-form').submit();">
                     {{ __('Logout') }}
                 </a>

                 <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                     @csrf
                 </form>
                </div>
            </div>
        </div>
    </div>
</div>







<!-- Button trigger modal -->

  
  <!-- Modal -->
  <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          ...
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Save changes</button>
        </div>
      </div>
    </div>
  </div>


















@endsection
