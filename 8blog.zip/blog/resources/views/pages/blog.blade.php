
<!-- Jquery needed -->
@extends('static')

@section('title','Blog')


@section('head_tags')
<style>
.w-100{
   height: 460px;
}

</style>

@endsection

@section('content')




<!------ BLOG POST ---------->









<section class="blog-me pt-100 pb-100" id="blog">
   <div class="container">
      <div class="row">
         <div class="col-xl-6 mx-auto text-center">
            <div class="section-title mb-100">
               <p>what i can do</p>
               <h4>All Blogs</h4>
            </div>
         </div>
      </div>
      <div class="row">


@foreach ($posts as $posts)
<div class="col-lg-4 col-md-12">
   <!-- Single Blog -->
   <div class="single-blog">
      <div class="blog-img">
         <img src="{{ asset('images/'. $posts->image)}}" alt="">
         <div class="post-category">
            <a href="#">Creative</a>
         </div>
      </div>
      <div class="blog-content">
         <div class="blog-title">
            <h4><a href="#">{{$posts->title}}</a></h4>
            <div class="meta">
               <ul>
                  <li>{{ date('M j, Y h:ia', strtotime($posts->created_at))  }}</li>
               </ul>
            </div>
         </div>
         <p>{{ substr(strip_tags($posts->body),0,300)}}</p>
         <a href="{{ url('/blog/post/'. $posts->id) }}" class="box_btn">read more</a>
      </div>
   </div>
</div>
@endforeach






      </div>
   </div>
</section>





@endsection