
<!-- Jquery needed -->
 @extends('static')

@section('title','Blog')


@section('head_tags')
<style>
.w-100{
   height: 460px;
}

.about{
	cursor: pointer;
	background-color: #26272b;
	color: #FFFFFF;
	padding-top: 20px;
	padding-bottom: 30px;
}
.about h1 {
	padding: 10px 0;
	margin-bottom: 20px;
   color:white;
}
.about h2 {
	opacity: .8;
}
.about span {
	display: block;
	width: 100px;
	height: 100px;
	line-height: 100px;
	margin:auto;
	border-radius:50%;  
	font-size: 40px;
	color: #26272b;
	opacity: 0.7;
	background-color: yellow;
	border: 2px solid yellow;

	webkit-transition:all .5s ease;
 	moz-transition:all .5s ease;
 	os-transition:all .5s ease;
 	transition:all .5s ease;

}
.about-item:hover span{
	opacity: 1;	
	border: 2px solid yellow;
	font-size: 42px;
	-webkit-transform: scale(1.1,1.1) rotate(360deg) ;
	-moz-transform: scale(1.1,1.1) rotate(360deg) ;
	-o-transform: scale(1.1,1.1) rotate(360deg) ;
	transform: scale(1.1,1.1) rotate(360deg) ;
}
.about-item:hover h2{
	opacity: 1;
	-webkit-transform: scale(1.1,1.1)  ;
	-moz-transform: scale(1.1,1.1)  ;
	-o-transform: scale(1.1,1.1)  ;
	transform: scale(1.1,1.1) ;
}
.about .lead{
	color: white;
	font-size: 14px;
	font-weight: bold;
}



</style>

@endsection

@section('content')




<div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
   <div class="carousel-inner">
     <div class="carousel-item active">
         <img src="{{ asset('images/banner.jpeg')}}" class="d-block w-100" alt="...">
     </div>

   </div>
 </div>


<!------ BLOG POST ---------->









<section class="blog-me pt-100 pb-100" id="blog">
   <div class="container">
      <div class="row">
         <div class="col-xl-6 mx-auto text-center">
            <div class="section-title mb-100">
               <p>what i can do</p>
               <h4>latest blog</h4>
               <p><a href="/blog" class="btn btn-dark" >View All Post >></a></p>
            </div>
         </div>
      </div>
      <div class="row">


@foreach ($posts as $posts)
<div class="col-lg-4 col-md-12">
   <!-- Single Blog -->
   <div class="single-blog">
      <div class="blog-img">
         <img src="{{ asset('images/'. $posts->image)}}" alt="">
         <div class="post-category">
            <a href="#">{{$posts->category->name}}</a>
         </div>
      </div>
      <div class="blog-content">
         <div class="blog-title">
            <h4><a href="#">{{$posts->title}}</a></h4>
            <div class="meta">
               <ul>
                  <li>{{ date('M j, Y h:ia', strtotime($posts->created_at))  }}</li>
               </ul>
            </div>
         </div>
         <p>{{ substr(strip_tags($posts->body),0,300)}}</p>
         <a href="{{ url('/blog/post/'. $posts->id) }}" class="box_btn">read more</a>
      </div>
   </div>
</div>
@endforeach






      </div>
   </div>
</section>





{{-- About Us ------  --}}















<section class="text-center about">
   <h1>About US</h1>
   <div class="container">
     <div class="row">
       <div class="col-lg-4 col-sm-6 col-ex-12 about-item wow lightSpeedIn" data-wow-offset="200" >
         <span class="fa fa-group"></span>
         <h2>Section 1</h2>
         <p class="lead">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>
       </div>
       <div class="col-lg-4 col-sm-6 col-ex-12 about-item wow lightSpeedIn" data-wow-offset="200">
         <span class="fa fa-info"></span>
         <h2>Section 2 </h2>
         <p class="lead">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum </p>
       </div>
       <div class="clearfix visible-md-block visible-sm-block"></div>
       <div class="col-lg-4 col-sm-6 col-ex-12 about-item wow lightSpeedIn" data-wow-offset="200">
         <span class="fa fa-file"></span>
         <h2>Section 3</h2>
         <p class="lead">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>
       </div>
       
     </div>
     
   </div>
 </section>



 <a class="dropdown-item" href="{{ route('logout') }}"
 onclick="event.preventDefault();
               document.getElementById('logout-form').submit();">
  {{ __('Logout') }}
</a>

<form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
  @csrf
</form>








@endsection 