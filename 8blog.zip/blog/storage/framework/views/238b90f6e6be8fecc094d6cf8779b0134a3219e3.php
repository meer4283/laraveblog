<?php $__env->startSection('head_tags'); ?>

<script src="https://cdn.tiny.cloud/1/qixyqom2q3ozdkbv5uab0u4vv8hh2obcxyuyqzeuxh761y6t/tinymce/5/tinymce.min.js"></script>
<script>
tinymce.init({
    selector: 'textarea'
});
</script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('title','ali'); ?>

<?php $__env->startSection('content'); ?>

<style>
row{
    width: 0% ;
}
</style>

<div class="row">
    <div class="col-1"></div>
    <div class="col-7">
        



       





<?php echo Form::model($post, ['route' => ['posts.update', $post->id], 'method' => 'PUT','files' => true]); ?>


<?php echo Form::label('title','Title:');; ?>

<?php echo e(Form::text('title', null, [ 'class'=> 'form-control'])); ?>



<?php echo Form::label('featured_image','Upload Featured Image');; ?>

<?php echo Form::file('featured_image');; ?>




<?php echo Form::label('body','Post Body:');; ?>

<?php echo e(Form::textarea('body', null, [ 'class'=> 'form-control'])); ?>



        


    <?php echo Html::linkRoute('posts.show', 'Cancel', array($post->id),array('class' =>'btn btn-danger btn-block')); ?>

    
    <?php echo e(Form::submit('Save Changes', ['class'=> 'btn btn-dark btn-block'])); ?>

  

    </div>
        </div>

    <div class="col-4">col-4</div>
  </div>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('static', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel Project\6blog\blog\resources\views/post/edit.blade.php ENDPATH**/ ?>