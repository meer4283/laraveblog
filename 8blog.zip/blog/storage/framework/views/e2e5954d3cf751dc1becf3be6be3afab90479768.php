<?php $__env->startSection('title','Create Post'); ?>

<?php $__env->startSection('head_tags'); ?>

<script src="https://cdn.tiny.cloud/1/qixyqom2q3ozdkbv5uab0u4vv8hh2obcxyuyqzeuxh761y6t/tinymce/5/tinymce.min.js"></script>
<script>
tinymce.init({
    selector: 'textarea'
});
</script>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-md-8 col-md-offset-2">

<?php echo Form::open(['route' => 'posts.store', 'files' => true ]); ?>


<?php echo Form::label('title','Title:');; ?>

<?php echo Form::text('title',null, array('class' => 'form-control' )); ?>





<?php echo Form::label('featured_image','Upload Featured Image');; ?>

<?php echo Form::file('featured_image');; ?>



<?php echo Form::label('body','Post Body:');; ?>

<?php echo Form::textarea('body',null, array('class' => 'form-control' )); ?>


<?php echo Form::label('category_id','Put Category ID:');; ?>

<?php echo Form::text('category_id',null, array('class' => 'form-control' )); ?>



<br>

<?php echo Form::submit('Create Post', array('class' => 'btn btn-success btn-lg btn-block')); ?>


<?php echo Form::close(); ?>


</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('static', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel Project\6blog\blog\resources\views/post/create.blade.php ENDPATH**/ ?>