<!-- Jquery needed -->


<?php $__env->startSection('title','Blog'); ?>


<?php $__env->startSection('head_tags'); ?>
<style>
.w-100{
   height: 460px;
}

</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>




<!------ BLOG POST ---------->









<section class="blog-me pt-100 pb-100" id="blog">
   <div class="container">
      <div class="row">
         <div class="col-xl-6 mx-auto text-center">
            <div class="section-title mb-100">
               <p>what i can do</p>
               <h4>All Blogs</h4>
            </div>
         </div>
      </div>
      <div class="row">


<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-lg-4 col-md-12">
   <!-- Single Blog -->
   <div class="single-blog">
      <div class="blog-img">
         <img src="<?php echo e(asset('images/'. $posts->image)); ?>" alt="">
         <div class="post-category">
            <a href="#">Creative</a>
         </div>
      </div>
      <div class="blog-content">
         <div class="blog-title">
            <h4><a href="#"><?php echo e($posts->title); ?></a></h4>
            <div class="meta">
               <ul>
                  <li><?php echo e(date('M j, Y h:ia', strtotime($posts->created_at))); ?></li>
               </ul>
            </div>
         </div>
         <p><?php echo e(substr(strip_tags($posts->body),0,300)); ?></p>
         <a href="<?php echo e(url('/blog/post/'. $posts->id)); ?>" class="box_btn">read more</a>
      </div>
   </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>






      </div>
   </div>
</section>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('static', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel Project\6blog\blog\resources\views/pages/blog.blade.php ENDPATH**/ ?>