<?php $__env->startSection('title',$post->title); ?>

<?php $__env->startSection('content'); ?>

<style>
row{
    width: 0% ;
}
</style>

<div class="row">
    <div class="col-1"></div>
    <div class="col-7">
    <?php echo Form::model($post, ['route' => ['posts.destroy', $post->id], 'method' => 'DELETE']); ?>   
        <h2><?php echo e($post->title); ?></h2>

        
    <img src="<?php echo e(asset('images/'. $post->image)); ?>" alt="">
        <p><?php echo $post->body; ?></p>
        <p><?php echo e(date('M j, Y h:ia', strtotime($post->created_at))); ?></p>


    <?php echo Html::linkRoute('posts.edit', 'Edit', array($post->id),array('class' =>'btn btn-primary btn-block')); ?>

    
    <?php echo e(Form::submit('Delete', ['class'=> 'btn btn-danger btn-block'])); ?>

    </div>
        </div>

    <div class="col-4">col-4</div>
  </div>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('static', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel Project\6blog\blog\resources\views/post/show.blade.php ENDPATH**/ ?>