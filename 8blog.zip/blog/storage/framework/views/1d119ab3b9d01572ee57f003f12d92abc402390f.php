<?php $__env->startSection('title','All Categories'); ?>

<?php $__env->startSection('content'); ?>








<div class="container-fluid">
    <div class="row">
      <div class="col-sm">
       <h1>All Categories </h1>
      </div>
      <div class="col-sm">
        
      </div>
      <div class="col-sm">
        <a href="<?php echo e(route('categories.create')); ?> " class="btn btn-dark">Add New Post</a>
      </div> 
    </div>
  </div>



<div class="container-fluid">
<table class="table">
    <thead class="thead-dark">
      <tr>
        <th scope="col">ID</th>
        <th scope="col">Category Name</th>
      
        <th scope="col">PUBLISHED DATE</th>
        <th scope="col">ACTION</th>
      </tr>
    </thead>
    <tbody>


        
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo Form::model($categories, ['route' => ['categories.destroy', $categories->id], 'method' => 'DELETE']); ?>   
    
<tr>
    <th scope="row"><?php echo e($categories->id); ?></th>
    <td><?php echo e($categories->name); ?></td>
    
    <td><?php echo e(date('M j, Y h:ia', strtotime($categories->created_at))); ?></td>
    <td>
    
        <a href="<?php echo e(route('categories.edit',$categories->id )); ?>" class="btn btn-dark"><i class="fas fa-edit"></i></a>

        

        <?php echo e(FORM::button('<i class="fa fa-trash"></i>',['class'=>'btn btn-danger','type'=>'submit','id'=>'id-button'])); ?>


         </td>
  </tr>
 

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
  </table>

</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('static', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel Project\6blog\blog\resources\views/category/listcategory.blade.php ENDPATH**/ ?>