<?php $__env->startSection('title','All post'); ?>

<?php $__env->startSection('content'); ?>








<div class="container-fluid">
    <div class="row">
      <div class="col-sm">
       <h1>All Posts </h1>
      </div>
      <div class="col-sm">
        
      </div>
      <div class="col-sm">
        <a href="<?php echo e(route('posts.create')); ?> " class="btn btn-dark">Add New Post</a>
      </div> 
    </div>
  </div>



<div class="container-fluid">
<table class="table">
    <thead class="thead-dark">
      <tr>
        <th scope="col">ID</th>
        <th scope="col">TITLE</th>
        <th scope="col">POST</th>
        <th scope="col">PUBLISHED DATE</th>
        <th scope="col">ACTION</th>
      </tr>
    </thead>
    <tbody>


        
<?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo Form::model($post, ['route' => ['posts.destroy', $post->id], 'method' => 'DELETE']); ?>   
    
<tr>
    <th scope="row"><?php echo e($post->id); ?></th>
    <td><?php echo e($post->title); ?></td>
    <td><?php echo e(substr(strip_tags($post->body),0,100)); ?></td>   
    <td><?php echo e(date('M j, Y h:ia', strtotime($post->created_at))); ?></td>

    <td><a href="<?php echo e(route('posts.show',$post->id )); ?>" class="btn btn-dark" >
        <i class="fas fa-eye"></i></a>
        <a href="<?php echo e(route('posts.edit',$post->id )); ?>" class="btn btn-dark"><i class="fas fa-edit"></i></a>

        

        <?php echo e(FORM::button('<i class="fa fa-trash"></i>',['class'=>'btn btn-danger','type'=>'submit','id'=>'id-button'])); ?>


         
  </tr>
 

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
  </table>

</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('static', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel Project\6blog\blog\resources\views/post/index.blade.php ENDPATH**/ ?>