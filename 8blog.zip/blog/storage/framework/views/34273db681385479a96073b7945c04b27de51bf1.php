<?php $__env->startSection('title',$post->title); ?>

<?php $__env->startSection('head_tags'); ?>

<style>

    

</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    





<div class="row">
    <div class="col-2"></div>
    <div class="col-8">
        <img src="<?php echo e(asset('images/'. $post->image)); ?>" alt="">
    
        <h1><?php echo e($post->title); ?></h1>
    <h6>Category<?php echo e($post->category->name); ?></h6>
        <p><?php echo $post->body; ?></p>

    </div>

    
    
  </div>

  <div class="col-2"></div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('static', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel Project\6blog\blog\resources\views/post/single.blade.php ENDPATH**/ ?>