<?php $__env->startSection('title','Create Categories'); ?>

<?php $__env->startSection('content'); ?>





<?php echo Form::open(['route' => 'categories.store', 'files' => true ]); ?>


<?php echo Form::label('name','Category Name:');; ?>

<?php echo Form::text('name',null, array('class' => 'form-control' )); ?>







<?php echo Form::submit('Create Post', array('class' => 'btn btn-success btn-lg btn-block')); ?>


<?php echo Form::close(); ?>










<?php $__env->stopSection(); ?>
<?php echo $__env->make('static', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel Project\6blog\blog\resources\views/category/createcategory.blade.php ENDPATH**/ ?>