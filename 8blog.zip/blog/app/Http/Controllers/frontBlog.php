<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class frontBlog extends Controller
{
public function getall(){
//retrieving all post in the blog
$posts = Post::all();


return view('pages.blog')->with('posts',$post);

}


}
