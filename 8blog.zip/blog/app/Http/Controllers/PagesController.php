<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Post;
use Intervention\Image\ImageManagerStatic as Image;


class PagesController extends Controller
{
   function getHome(){


    $posts =  Post::all();


     return view('pages.home')->with('posts',$posts);
   }



   function getBlog(){

    // $query = $request->input('query');

    // $product = DB::table('products')->where('title','LIKE','%'.$query.'%')->get();
    $posts =  Post::all();

    return view('pages.blog')->with('posts',$posts);
     }





  public function search(Request $request){

    $q = $request->input('q');
    $user = Post::where('title','LIKE','%'.$q.'%')->get();

      return view('post.search')->with('posts',$user)->with('q',$q);
  }














}
