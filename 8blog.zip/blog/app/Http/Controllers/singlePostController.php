<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Post;
class singlePostController extends Controller
{
    public function show($id){
        
    $post = Post::find($id);

    return view('post.single')->with('post',$post);


    }
}
